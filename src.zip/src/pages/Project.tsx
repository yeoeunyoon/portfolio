import React from 'react';

const Project: React.FC = () => {
  return (
    <div className="project-page">
      <h1>Project Page</h1>
      <p>This is the Contact page content </p>
    </div>
  );
};

export default Project
