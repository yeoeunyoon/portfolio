import React from 'react';

const Contact: React.FC = () => {
  return (
    <div className="contact-page">
      <h1>Contact Page</h1>
      <p>This is the Contact page content </p>
    </div>
  );
};

export default Contact
