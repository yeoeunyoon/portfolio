import React from 'react';

const Experience: React.FC = () => {
  return (
    <div className="experience-page">
      <h1>Experience Page</h1>
      <p>This is the Experience page content.</p>
    </div>
  );
};

export default Experience;
