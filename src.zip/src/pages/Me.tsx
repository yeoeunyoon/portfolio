import React from 'react';

const Me: React.FC = () => {
  return (
    <div className="me-page">
      <h1>Me Page</h1>
      <p>This is the Me page content.</p>
    </div>
  );
};

export default Me;
