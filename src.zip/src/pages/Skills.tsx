import React from 'react';

const Skills: React.FC = () => {
  return (
    <div className="skills-page">
      <h1>Skills Page</h1>
      <p>This is the Skills page content </p>
    </div>
  );
};

export default Skills
