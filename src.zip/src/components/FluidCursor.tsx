'use client';
import { useEffect } from 'react';
import fluidCursor from '../hooks/use-FluidCursor';

const FluidCursor = () => {
  useEffect(() => {
    const canvas = document.getElementById('fluid') as HTMLCanvasElement | null;
    if (!canvas) return;

    const resize = () => {
      const dpr = window.devicePixelRatio || 1;
      canvas.width = window.innerWidth * dpr;
      canvas.height = window.innerHeight * dpr;
      canvas.style.width = '100vw';
      canvas.style.height = '100vh';
    };

    // ✅ resize multiple times to ensure canvas fully mounted
    resize();
    setTimeout(resize, 50);
    setTimeout(resize, 200);

    window.addEventListener('resize', resize);

    // ✅ run fluid AFTER render cycle
    requestAnimationFrame(() => {
      setTimeout(() => {
        fluidCursor();
      }, 10);
    });

    return () => {
      window.removeEventListener('resize', resize);
    };
  }, []);

  return (
    <div
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100vw',
        height: '100vh',
        zIndex: -1, // 👈 fluid is background
        pointerEvents: 'none',
        overflow: 'hidden',
      }}
    >
      <canvas id="fluid" />
    </div>
  );
};

export default FluidCursor;
